﻿
namespace Shop.Web.Data
{
    using Shop.Web.Data.Entities;
    public interface IContryRepository : IGenericRepository<Contry>
    {
    }
}
