﻿namespace Shop.Web.Data
{
    using Entities;

    public interface IProductRepository : IGenericRepository<Product>
    {
    }
}

