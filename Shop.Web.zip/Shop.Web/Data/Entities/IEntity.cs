﻿
namespace Shop.Web.Data.Entities
{
	public interface IEntity
	{
		int Id { get; set; }
    }

}
