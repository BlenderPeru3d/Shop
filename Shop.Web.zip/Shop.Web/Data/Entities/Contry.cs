﻿namespace Shop.Web.Data.Entities
{
    public class Contry : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
